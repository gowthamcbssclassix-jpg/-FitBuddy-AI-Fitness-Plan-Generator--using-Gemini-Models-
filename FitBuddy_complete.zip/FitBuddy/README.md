# FitBuddy – AI Fitness Plan Generator

Complete FastAPI + Jinja2 + SQLite + Gemini application based on the supplied FitBuddy project document.

## Features

- Personalized 7-day workout plan
- Nutrition/recovery tip
- Feedback-based AI plan revision
- SQLite persistence with SQLAlchemy
- Jinja2 web interface
- Admin dashboard with original and updated plans
- JSON API endpoints and automatic Swagger/OpenAPI docs
- Demo mode so the project runs without an API key
- Current Google GenAI SDK integration

## Run in VS Code

```bash
python -m venv venv
```

Windows PowerShell:
```powershell
.env\Scripts\Activate.ps1
```

Windows CMD:
```cmd
venv\Scriptsctivate
```

macOS/Linux:
```bash
source venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
```

Copy `.env.example` to `.env`. The default `DEMO_MODE=true` works without Gemini.

Start:
```bash
uvicorn app.main:app --reload
```

Open:
- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/view-all-users

Admin defaults:
- username: `admin`
- password: `fitbuddy123`

Change admin credentials in `.env`.

## Real Gemini mode

Get a Gemini API key from Google AI Studio and set:

```env
GOOGLE_API_KEY=your_key
DEMO_MODE=false
```

The application uses `gemini-2.5-pro` for workout generation/revision and `gemini-2.5-flash` for quick nutrition/recovery output. These are configurable in `.env`.

## API examples

POST `/api/generate`:

```json
{
  "name": "Alex",
  "user_id": "FB001",
  "age": 24,
  "weight": 68,
  "goal": "muscle gain",
  "intensity": "medium"
}
```

POST `/api/feedback`:

```json
{
  "user_id": "FB001",
  "feedback": "Add more cardio and one extra recovery day."
}
```

GET `/api/users` requires admin Basic Auth.

GET `/api/health` checks application/database configuration.

## Test

```bash
pytest -q
```

Tests use demo mode and do not require a Gemini API key.

## Notes

The supplied document refers to the older `google-generativeai` package and Gemini 1.5 Pro/Flash. This implementation keeps the intended Pro/Flash architecture but uses Google's current `google-genai` SDK and configurable current model IDs.

FitBuddy is a fitness-planning demonstration, not a medical/clinical system. AI output should be treated as general information and reviewed by a qualified professional where appropriate.
