from secrets import compare_digest
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from app.config import settings

security = HTTPBasic()

def require_admin(credentials: HTTPBasicCredentials = Depends(security)):
    if not (
        compare_digest(credentials.username, settings.admin_username)
        and compare_digest(credentials.password, settings.admin_password)
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username
