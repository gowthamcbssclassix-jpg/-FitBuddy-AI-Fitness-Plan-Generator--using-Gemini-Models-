from typing import Literal
from pydantic import BaseModel, Field, field_validator

Goal = Literal["weight loss", "muscle gain", "general wellness", "flexibility"]
Intensity = Literal["low", "medium", "high"]

class UserInput(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    user_id: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    age: int = Field(ge=13, le=100)
    weight: float = Field(gt=20, le=500)
    goal: Goal
    intensity: Intensity

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        return " ".join(value.strip().split())

class FeedbackRequest(BaseModel):
    user_id: str = Field(min_length=2, max_length=50, pattern=r"^[A-Za-z0-9_-]+$")
    feedback: str = Field(min_length=3, max_length=1000)

class WorkoutDay(BaseModel):
    day: str
    focus: str
    warm_up: str
    main_workout: list[str]
    cooldown: str

class WorkoutPlan(BaseModel):
    title: str
    overview: str
    days: list[WorkoutDay] = Field(min_length=7, max_length=7)
    safety_note: str

class NutritionTip(BaseModel):
    tip: str
    hydration: str
    recovery: str
