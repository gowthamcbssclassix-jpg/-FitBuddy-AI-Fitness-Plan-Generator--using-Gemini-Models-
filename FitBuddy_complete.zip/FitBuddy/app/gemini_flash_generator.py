from app.config import settings
from app.gemini_client import get_client
from app.schemas import NutritionTip, UserInput

def _demo_tip(user: UserInput) -> NutritionTip:
    tips = {
        "weight loss": "Build meals around vegetables, a protein source, whole-food carbohydrates, and sensible portions.",
        "muscle gain": "Include a protein-rich food in each meal, such as eggs, fish, chicken, beans, tofu, or Greek yogurt.",
        "general wellness": "Aim for balanced meals with vegetables or fruit, protein, whole-food carbohydrates, and healthy fats.",
        "flexibility": "Support recovery with balanced meals, adequate fluids, and protein distributed across the day.",
    }
    return NutritionTip(
        tip=tips[user.goal],
        hydration="Drink fluids regularly and increase intake around exercise and hot weather.",
        recovery="Prioritize consistent sleep and allow recovery days between demanding sessions.",
    )

def generate_nutrition_tip_with_flash(user: UserInput) -> NutritionTip:
    if settings.demo_mode or not settings.google_api_key:
        return _demo_tip(user)
    prompt = f"""
Give concise nutrition and recovery guidance for age {user.age}, weight {user.weight} kg,
goal {user.goal}, intensity {user.intensity}. Return practical general wellness guidance,
not medical advice. Avoid calorie prescriptions, disease treatment, or extreme restrictions.
Mention hydration and recovery.
"""
    response = get_client().models.generate_content(
        model=settings.gemini_fast_model,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": NutritionTip,
            "temperature": 0.3,
        },
    )
    return NutritionTip.model_validate_json(response.text)
