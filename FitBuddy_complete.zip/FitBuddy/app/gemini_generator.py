from app.config import settings
from app.gemini_client import get_client
from app.schemas import UserInput, WorkoutPlan

def _demo_plan(user: UserInput) -> WorkoutPlan:
    focus_map = {
        "weight loss": ["Full Body + Cardio", "Lower Body", "Cardio + Core", "Recovery", "Upper Body", "Intervals", "Mobility + Light Cardio"],
        "muscle gain": ["Full Body", "Upper Body", "Lower Body", "Recovery", "Push + Core", "Pull + Legs", "Mobility + Light Strength"],
        "general wellness": ["Full Body", "Cardio", "Upper Body", "Mobility", "Lower Body", "Full Body", "Recovery + Stretching"],
        "flexibility": ["Full Body Mobility", "Lower Body Mobility", "Yoga + Core", "Recovery", "Upper Body Mobility", "Dynamic Stretching", "Gentle Flow"],
    }
    days = []
    for i, focus in enumerate(focus_map[user.goal], 1):
        low = focus.lower()
        if "recovery" in low:
            workout = ["20–30 min easy walk", "10–15 min gentle mobility"]
        elif "cardio" in low or "interval" in low:
            workout = ["20–30 min brisk walking/cycling", "3 × 5 min moderate intervals with 2 min easy recovery", "Core: 3 × 10–12 dead bugs"]
        elif "mobility" in low or "yoga" in low or "stretch" in low:
            workout = ["10 min dynamic mobility", "3 × 30–45 sec controlled stretches per major area", "Core: 3 × 20–30 sec plank"]
        else:
            workout = ["Squat or chair squat: 3 × 8–12", "Push-up or incline push-up: 3 × 8–12", "Row/band row: 3 × 10–12", "Glute bridge: 3 × 10–15"]
        days.append({
            "day": f"Day {i}",
            "focus": focus,
            "warm_up": "5–10 minutes of easy movement and dynamic mobility.",
            "main_workout": workout,
            "cooldown": "5–10 minutes easy movement and comfortable stretching.",
        })
    return WorkoutPlan(
        title=f"7-Day {user.goal.title()} Plan",
        overview=f"A {user.intensity}-intensity starter plan for {user.name}, designed around {user.goal}.",
        days=days,
        safety_note="Adjust difficulty to your current ability. Stop if you experience pain, dizziness, or other concerning symptoms.",
    )

def generate_workout_gemini(user: UserInput) -> WorkoutPlan:
    if settings.demo_mode or not settings.google_api_key:
        return _demo_plan(user)
    prompt = f"""
Create a safe, practical 7-day fitness plan.

User: {user.name}, age {user.age}, weight {user.weight} kg,
goal {user.goal}, preferred intensity {user.intensity}.

Return exactly seven days. Each day must include day, focus, warm_up,
main_workout with 2–5 exercise/activity strings including sets/reps or
duration, and cooldown. Include variety and at least one recovery/light day.
Do not diagnose conditions, prescribe medication, or make extreme claims.
"""
    response = get_client().models.generate_content(
        model=settings.gemini_workout_model,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": WorkoutPlan,
            "temperature": 0.5,
        },
    )
    return WorkoutPlan.model_validate_json(response.text)
