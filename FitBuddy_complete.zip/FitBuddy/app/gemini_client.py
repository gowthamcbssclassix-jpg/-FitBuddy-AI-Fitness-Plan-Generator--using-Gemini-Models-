from functools import lru_cache
from google import genai
from app.config import settings

@lru_cache
def get_client() -> genai.Client:
    if not settings.google_api_key:
        raise RuntimeError("GOOGLE_API_KEY is not configured.")
    return genai.Client(api_key=settings.google_api_key)
