from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models import Plan, User

def get_user(db: Session, user_id: str):
    return db.scalar(select(User).where(User.user_id == user_id))

def save_user(db: Session, data):
    existing = get_user(db, data.user_id)
    if existing:
        for key, value in data.model_dump().items():
            setattr(existing, key, value)
        db.commit()
        db.refresh(existing)
        return existing
    user = User(**data.model_dump())
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def save_plan(db: Session, user_id: str, original_plan: str, nutrition_tip: str):
    plan = Plan(user_id=user_id, original_plan=original_plan, nutrition_tip=nutrition_tip)
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan

def get_latest_plan(db: Session, user_id: str):
    return db.scalar(select(Plan).where(Plan.user_id == user_id).order_by(Plan.id.desc()))

def update_plan(db: Session, plan, updated_plan: str, feedback: str, nutrition_tip: str):
    plan.updated_plan = updated_plan
    plan.feedback = feedback
    plan.nutrition_tip = nutrition_tip
    db.commit()
    db.refresh(plan)
    return plan

def get_all_users(db: Session):
    return list(db.scalars(select(User).order_by(User.created_at.desc())).all())

def delete_user(db: Session, user_id: str):
    user = get_user(db, user_id)
    if not user:
        return False
    plans = list(db.scalars(select(Plan).where(Plan.user_id == user_id)).all())
    for plan in plans:
        db.delete(plan)
    db.delete(user)
    db.commit()
    return True
