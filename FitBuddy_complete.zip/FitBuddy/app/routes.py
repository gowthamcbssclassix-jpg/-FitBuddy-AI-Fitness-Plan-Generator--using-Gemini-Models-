import json
from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.auth import require_admin
from app.config import settings
from app.crud import delete_user, get_all_users, get_latest_plan, get_user, save_plan, save_user, update_plan
from app.database import get_db
from app.gemini_flash_generator import generate_nutrition_tip_with_flash
from app.gemini_generator import generate_workout_gemini
from app.schemas import FeedbackRequest, UserInput
from app.updated_plan import update_workout_plan

templates = Jinja2Templates(directory="templates")
router = APIRouter()

def plan_json(plan):
    return json.dumps(plan.model_dump(), indent=2, ensure_ascii=False)

def nutrition_json(tip):
    return json.dumps(tip.model_dump(), indent=2, ensure_ascii=False)

@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(
    request: Request,
    name: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        user = UserInput(name=name, user_id=user_id, age=age, weight=weight, goal=goal, intensity=intensity)
        save_user(db, user)
        plan = generate_workout_gemini(user)
        nutrition = generate_nutrition_tip_with_flash(user)
        save_plan(db, user.user_id, plan_json(plan), nutrition_json(nutrition))
        return templates.TemplateResponse(
            "result.html",
            {"request": request, "user": user, "workout_plan": plan, "nutrition": nutrition, "message": None},
        )
    except Exception as exc:
        return templates.TemplateResponse("index.html", {"request": request, "error": str(exc)}, status_code=400)

@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(request: Request, user_id: str = Form(...), feedback: str = Form(...), db: Session = Depends(get_db)):
    try:
        data = FeedbackRequest(user_id=user_id, feedback=feedback)
        record = get_user(db, data.user_id)
        plan_record = get_latest_plan(db, data.user_id)
        if not record or not plan_record:
            raise HTTPException(status_code=404, detail="User or plan not found.")
        user = UserInput(
            name=record.name, user_id=record.user_id, age=record.age, weight=record.weight,
            goal=record.goal, intensity=record.intensity
        )
        updated = update_workout_plan(user, plan_record.original_plan, data.feedback)
        nutrition = generate_nutrition_tip_with_flash(user)
        update_plan(db, plan_record, plan_json(updated), data.feedback, nutrition_json(nutrition))
        return templates.TemplateResponse(
            "result.html",
            {"request": request, "user": user, "workout_plan": updated, "nutrition": nutrition,
             "message": "Your workout plan was updated successfully."},
        )
    except Exception as exc:
        return templates.TemplateResponse("index.html", {"request": request, "error": str(exc)}, status_code=400)

@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, _: str = Depends(require_admin), db: Session = Depends(get_db)):
    rows = [{"user": u, "plan": get_latest_plan(db, u.user_id)} for u in get_all_users(db)]
    return templates.TemplateResponse("all_users.html", {"request": request, "rows": rows})

@router.post("/admin/delete/{user_id}")
def admin_delete_user(user_id: str, _: str = Depends(require_admin), db: Session = Depends(get_db)):
    delete_user(db, user_id)
    return RedirectResponse("/view-all-users", status_code=status.HTTP_303_SEE_OTHER)

@router.post("/api/generate")
def api_generate(data: UserInput, db: Session = Depends(get_db)):
    save_user(db, data)
    plan = generate_workout_gemini(data)
    nutrition = generate_nutrition_tip_with_flash(data)
    save_plan(db, data.user_id, plan_json(plan), nutrition_json(nutrition))
    return {"user": data.model_dump(), "plan": plan.model_dump(), "nutrition": nutrition.model_dump()}

@router.post("/api/feedback")
def api_feedback(data: FeedbackRequest, db: Session = Depends(get_db)):
    record = get_user(db, data.user_id)
    plan_record = get_latest_plan(db, data.user_id)
    if not record or not plan_record:
        raise HTTPException(status_code=404, detail="User or plan not found.")
    user = UserInput(
        name=record.name, user_id=record.user_id, age=record.age, weight=record.weight,
        goal=record.goal, intensity=record.intensity
    )
    updated = update_workout_plan(user, plan_record.original_plan, data.feedback)
    nutrition = generate_nutrition_tip_with_flash(user)
    update_plan(db, plan_record, plan_json(updated), data.feedback, nutrition_json(nutrition))
    return {"user_id": data.user_id, "feedback": data.feedback, "updated_plan": updated.model_dump(), "nutrition": nutrition.model_dump()}

@router.get("/api/users")
def api_users(_: str = Depends(require_admin), db: Session = Depends(get_db)):
    output = []
    for user in get_all_users(db):
        plan = get_latest_plan(db, user.user_id)
        output.append({
            "user_id": user.user_id, "name": user.name, "age": user.age,
            "weight": user.weight, "goal": user.goal, "intensity": user.intensity,
            "created_at": user.created_at.isoformat(),
            "latest_plan": None if not plan else {
                "original_plan": plan.original_plan,
                "updated_plan": plan.updated_plan,
                "feedback": plan.feedback,
            },
        })
    return output

@router.get("/api/health")
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {
        "status": "ok",
        "database": "ok",
        "ai_mode": "demo" if settings.demo_mode or not settings.google_api_key else "gemini",
        "workout_model": settings.gemini_workout_model,
        "fast_model": settings.gemini_fast_model,
    }
