from app.config import settings
from app.gemini_client import get_client
from app.gemini_generator import generate_workout_gemini
from app.schemas import UserInput, WorkoutPlan

def update_workout_plan(user: UserInput, original_plan: str, feedback: str) -> WorkoutPlan:
    if settings.demo_mode or not settings.google_api_key:
        plan = generate_workout_gemini(user)
        plan.overview += f" Feedback applied: {feedback.strip()}"
        low = feedback.lower()
        if "cardio" in low:
            plan.days[2].main_workout.insert(0, "Additional cardio: 15–20 minutes at a comfortable pace.")
        if "rest" in low or "recovery" in low:
            plan.days[3].focus = "Recovery / Rest"
            plan.days[3].main_workout = ["Easy walk if comfortable", "Gentle mobility for 10–15 minutes"]
        return plan

    prompt = f"""
Revise this original seven-day fitness plan using the feedback.

USER:
{user.model_dump_json()}

ORIGINAL PLAN:
{original_plan}

FEEDBACK:
{feedback}

Keep exactly seven days and preserve useful parts. Apply the feedback clearly.
Include warm-up, main workout, cooldown/recovery, and safety note. Do not provide
medical diagnosis or treatment.
"""
    response = get_client().models.generate_content(
        model=settings.gemini_workout_model,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": WorkoutPlan,
            "temperature": 0.5,
        },
    )
    return WorkoutPlan.model_validate_json(response.text)
