import os
os.environ["DEMO_MODE"] = "true"
os.environ["DATABASE_URL"] = "sqlite:///./test_fitbuddy.db"

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "FitBuddy" in response.text

def test_health():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_generate_and_feedback():
    payload = {
        "name": "Test User", "user_id": "TEST001", "age": 24,
        "weight": 68, "goal": "muscle gain", "intensity": "medium"
    }
    response = client.post("/api/generate", json=payload)
    assert response.status_code == 200
    assert len(response.json()["plan"]["days"]) == 7

    feedback = client.post("/api/feedback", json={
        "user_id": "TEST001",
        "feedback": "Add more cardio and one extra rest day."
    })
    assert feedback.status_code == 200
    assert len(feedback.json()["updated_plan"]["days"]) == 7

    client.post("/admin/delete/TEST001", auth=("admin", "fitbuddy123"), follow_redirects=False)
